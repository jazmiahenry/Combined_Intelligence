from rasa.nlu.components import Component


class IntentClassifier(Component):
    pass
